This two benchmark test sets are generated from the maps of Hefei, China and the central area (the area inside the 5th ring road) of Beijing, China. 
Instances in each set share the same undirected graph and vehicle capacity but with different task sets. 
For each edge, the cost is set to the length of the road it represents and so dose its demand (if it is a required edge). 

An instance is characterized as follows:

1st line: the name of the instance;
2nd line: the number of vertices;
3rd line: the depot vertex;
4th line: the number of required edges (tasks);
5th line: the number of non-required edges;
6th line: the number of vehicles;
7th line: the vehicle capacity;
8th line: the total cost of required edges;
9th line: description of the next lines;

Next, there is a line for each edge in the graph, e.g. in file 'Beijing-1.txt',
the line corresponding to edge (0,1) is:
0	1	437	0
The 1st and 2nd number is the nodes number ("0" and "1");
The 3rd number is the cost of the edge;
The 4th number is the demand of the edge ("0" indicates it is a non-required edge)
Please note that each edge appears only once, but should be considered twice since it is an undirected graph.

An "END" is added to the end of the file after all edges are listed.
