Each solution contains:
(1)The best node sequence, in which a task is represented with two nodes (i.e., head node and tail node) in parentheses, while the depot is listed directly;
(2)The best total cost.